import React, { Component } from 'react';

class Header extends Component {
    render() {
        return (
            <header style={{ width: "calc(100% - 60px)", padding: "30px", textAlign: "center", background:"cyan" }}>
                <img src="https://www-456m.aig.com/fnol/cmn/images/logo.png" />
            </header>
        )
    }
}

export { Header }