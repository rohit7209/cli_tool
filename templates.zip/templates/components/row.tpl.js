import React, { Component } from 'react';

const style = {
    row: {
        width: "100%",
        background: "red",
        content: "I am row",
        display: "flex",
        flexDirection:"row",
        flexWrap:"wrap"
    }
}

class Row extends Component {
    render() {
        return (
            <div style={{ ...style.row }}>{this.props.children}</div>
        );
    }
}

export { Row };