import React, { Component } from 'react';

class Footer extends Component {
    render() {
        return (
            <footer style={{ width: "calc(100% - 60px)", padding: "30px", textAlign: "center", background:"cyan" }}>
                Footer
            </footer>
        )
    }
}

export { Footer }