import React, { Component } from 'react';

class UserDetailsForm extends Component {
    render() {
        return (
            <div>
                <form>
                    <div><label>First Name: </label><input type="text" placeholder="name" /></div>
                    <div><label>Last Name: </label><input type="text" placeholder="name" /></div>
                    <div><label>Address: </label><textarea placeholder="name" ></textarea></div>
                    <div><label>Date of birth: </label><input type="date" /></div>
                    <div><input type="submit" /></div>
                </form>
            </div>
        )
    }
}

export { UserDetailsForm }