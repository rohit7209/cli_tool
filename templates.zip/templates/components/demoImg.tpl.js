import React, { Component } from 'react';


const style = {
    width: 'calc(100% - 2px)',
    border: '1px solid white',
    height: "100%"
}

class DemoImg extends Component {
    constructor(props) {
        super(props)
    }

    render() {
        return (
            <img src={`http://via.placeholder.com/${this.props.spec.dimension}`} style={style} {...this.props.spec.HTMLAttributes} />
        );
    }
}

export { DemoImg };