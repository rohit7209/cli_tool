import React, { Component } from 'react';


const colStyle={background: "white", border:"0px solid red"}

const style = {
    col_1: {
        ...colStyle,
        width: "8.33%",
    },
    col_2: {
        ...colStyle,
        width: "16.66%",
    },
    col_3: {
        ...colStyle,
        width: "25%",
    },
    col_4: {
        ...colStyle,
        width: "33.33%",
    },
    col_5: {
        ...colStyle,
        width: "41.66%",
    },
    col_6: {
        ...colStyle,
        width: "50%",
    },
    col_7: {
        ...colStyle,
        width: "58.33%",
    },
    col_8: {
        ...colStyle,
        width: "66.66%",
    },
    col_9: {
        ...colStyle,
        width: "75%",
    },
    col_10: {
        ...colStyle,
        width: "83.33%",
    },
    col_11: {
        ...colStyle,
        width: "91.66%",
    },
    col_12: {
        ...colStyle,
        width: "100%",
    }
}

class Col extends Component {
    render() {
        return (
            <div style={{ ...style["col_" + this.props.width] }}>{this.props.children}</div>
        );
    }
}

export { Col };