#!/usr/bin/env node

const chalk = require('chalk');
const program = require('commander');
const { exec } = require('child_process');
//const { scanTechnologies } = require('./app/core/gatherInformation');
//const createAppSource = require('./app/core/createAppSource');

//const moduleInfo = require('./app/technology/module-info')



program
    .arguments('<root>')
    .option('-u, --appconfig <appconfig>', 'URL to App configurations [-u http://dummy.com/path/to/config.zip]')
    .option('-t, --technology <technology>', 'technology to use while creating sources [-t react]')
    .option('-c, --createapp <createapp>', 'create app structure also [-c true, -c false]')
    .action(function (root) {
        const techService = new require('./app/service/technology.service.js')()

        if (!program.appconfig)
            throw new Error('--appconfig required')
        if (!program.technology)
            throw new Error(`--technology required`)
        if (!techService.validateTechnology(program.technology))
            throw new Error(`'${program.technology}' technology module is not available now`)


        const appService = new require('./app/service/app.service')({
            src: root,
            appConfig: program.appconfig,
            technology: program.technology,
            createApp: program.createapp
        });


        appService.createApp({}, () => { console.log('app created !') })

        //abcd.testFun()

        //createAppSource(root, program.appconfig, moduleInfo[program.technology])
    })
    .parse(process.argv);