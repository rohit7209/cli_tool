

module.exports = (function () {
    var fs = require('fs')
    var request = require('request')
    const path = require('path')
    const rimraf = require('rimraf')

    /**
     * @param {*} file : location of the file to be unzipped
     * @param {*} path : location where unzipped files to be saved
     * @param {*} callback : callback after extracting files
     */
    function unzipFile(file, path, callback) {
        const unzip = require('unzip')
        console.log(`Extracting ${file} ...`)
        const stream = fs.createReadStream(file)
        stream.pipe(unzip.Extract({ path })
            .on('close', function () {
                console.log(`Extracted to: ${path}`)
                callback();
            })
        );
    }


    /**
     * @param {*} file_url : url of the file
     * @param {*} targetPath : path where the file will be saved after downloading 
     * @param {*} callback : callback after downloading the file
     */
    function downloadFile(file_url, targetPath, callback) {
        var received_bytes = 0;
        var total_bytes = 0;

        var ProgressBar = require('progress');

        var barOpts = {
            width: 20,
            total: total_bytes,
            clear: true
        };

        var bar = new ProgressBar(' uploading [:bar] :percent :etas', barOpts);

        var out = fs.createWriteStream(targetPath);

        var req = request({
            method: 'GET',
            uri: file_url
        });
        req.pipe(out);
        req.on('response', function (data) {
            total_bytes = parseInt(data.headers['content-length']);
            barOpts.total = total_bytes
            bar = new ProgressBar('downloading [:bar] :percent :etas', barOpts);
        });
        req.on('data', function (chunk) {
            received_bytes += chunk.length;
            bar.tick(chunk.length);
        });
        req.on('end', function () {
            console.log("File succesfully downloaded");
            callback(targetPath)
        });
        req.on('error', function (err) {
            console.log(err)
        })
    }



    /**
     * @param {*} dir : directory where file is to be created
     * @param {*} fileName : new name of the file
     * @param {*} content : content to be written in the file
     */
    function writeFile(dir, fileName, content) {
        console.log(`writing file : '${dir}/${fileName}'`)
        createDir(dir)
        const file = fs.createWriteStream(dir + '/' + fileName)
        file.write(content)
        file.end();
    }



    /**
     * @param {*} fileName : location of the file to be read
     */
    function readFile(file) {
        return fs.readFileSync(file, 'UTF8');
    }

    /**
     * @param {*} dir : directory name to be created
     */
    function createDir(dir) {
        console.log(dir)
        if (!fs.existsSync(dir))
            fs.mkdirSync(dir);
    }


    /**
     * @param {*} src : source location
     * @param {*} dest : destination location
     */
    function copyDir(src, dest) {
        var exists = fs.existsSync(src);
        var stats = exists && fs.statSync(src);
        var isDirectory = exists && stats.isDirectory();
        if (exists && isDirectory) {
            if (!fs.existsSync(src))
                fs.mkdirSync(dest);
            fs.readdirSync(src).forEach(function (childItemName) {
                copyDir(path.join(src, childItemName), path.join(dest, childItemName));
            });
        } else {
            fs.linkSync(src, dest);
        }

    }

    return {
        unzipFile,
        downloadFile,
        readFile,
        writeFile,
        createDir,
        copyDir
    }

})()