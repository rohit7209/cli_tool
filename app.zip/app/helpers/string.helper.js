module.exports = (function () {

    /**
     * @param {*} string : String to be capitalized
     */
    function capitalize(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }



    /**
     * @param {*} jsonString : JSON String to be objectified in js object string format
     */
    function objectify(jsonString) {
        return jsonString.replace(/{"/g, "{").replace(/":/g, ":").replace(/,"/g, ",")
    }

    /**
     * @param {*} min : minimum length of random string
     * @param {*} max : maximum length of random string
     */
    function randomString(min, max) {
        min = Math.ceil(min);
        max = Math.floor(max);
        var length = Math.floor(Math.random() * (max - min)) + min;
        var text = "";
        var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        for (var i = 0; i < length; i++) {
            text += possible.charAt(Math.floor(Math.random() * possible.length));
        }
        return text;
    }


    return {
        capitalize,
        objectify,
        randomString
    }
})()