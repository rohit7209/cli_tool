module.exports = (function () {
    return function (args) {
        return Object.defineProperties({}, {
            src: {
                value: args.src,
                writable: false,
                enumerable: true,
                configurable: false
            },
            appConfig: {
                value: args.appConfig,
                writable: false,
                enumerable: true,
                configurable: false
            },
            technology: {
                value: args.technology,
                writable: false,
                enumerable: true,
                configurable: false
            },
            createApp: {
                value: args.createApp,
                writable: false,
                enumerable: true,
                configurable: false
            },
        });
    }
})()