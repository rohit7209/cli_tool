module.exports = (function () {
    return function (snippet, name, templates) {
        return Object.defineProperties({}, {
            snippet: {
                value: snippet,
                writable: false,
                enumerable: true,
                configurable: false
            },
            name: {
                value: name,
                writable: false,
                enumerable: true,
                configurable: false
            },
            templates: {
                value: templates,
                writable: false,
                enumerable: true,
                configurable: false
            }
        });
    }
})()