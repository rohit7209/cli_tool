
module.exports = (function () {
    //private properties of tech service
    const moduleInfo = require('./../config/module-info')
    const techModel = require('./../models/technology.model')

    var technology;


    //private functions of tech service
    var getDetails = (technology = this.technology) => {
        //technology = (technology) ? technology : this.technology
        console.log(moduleInfo)
        return new techModel(technology, moduleInfo[technology]['name'], moduleInfo[technology]['templates'])
    }

    var validateTechnology = (technology) => {
        return (moduleInfo[technology]) ? true : false
    }

    var createSourceCode = (args, callback) => {
        console.log('creating', args)
        new require(`./${args.technology}/createSourceCode`)(args, callback)

        callback()
    }

    return function (technology) {
        //constructor
        if (technology)
            this.technology = technology

        //revealing functions and properties
        return {
            getDetails,
            validateTechnology,
            createSourceCode,
        }
    }
})()
