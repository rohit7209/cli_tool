module.exports = (function () {
    var appDetails

    var updateDetails = (details) => {
        console.log(new require('./../models/app.model')(details))
        if (!this.appDetails)
            this.appDetails = new require('./../models/app.model')(details)
        console.log(this.appDetails)
    }

    var getDetails = () => {
        return appDetails
    }

    var createApp = (args, callback) => {
        const { downloadFile, unzipFile, createDir } = require('./../helpers/file.helper')
        const { randomString } = require('./../helpers/string.helper')

        const gName = `z${randomString(10, 20)}`;     //"z2hmCrZSseS"//
        const config_folder = `./${gName}.config`
        const template_folder = `./${gName}.tpl`


        //creating temp directories
        createDir(`${config_folder}`);
        createDir(`${template_folder}`);

        const techService = new require('./technology.service.js')(this.appDetails.technology)



        //downloading files
        downloadFile(`${techService.getDetails().templates}`, `${template_folder}/templates.zip`, (templatePath) => {
            downloadFile(`${this.appDetails.appConfig}`, `${config_folder}/config.zip`, (configPath) => {
                //extracting files
                unzipFile(templatePath, `${template_folder}`, () => {
                    unzipFile(configPath, `${config_folder}`, () => {
                        techService.createSourceCode({
                            root: this.appDetails.src,
                            config_folder,
                            template_folder,
                            technology: this.appDetails.technology
                        }, () => { console.log('source code created') })
                    })
                })
            });
        });
    }

    return function (details) {
        updateDetails(details)
        return {
            getDetails,
            createApp
        }
    }
})()