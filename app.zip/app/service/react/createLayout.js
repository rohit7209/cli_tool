const fs = require('fs')
const { writeFile } = require('./../../helpers/file.helper')
const { capitalize, objectify } = require('./../../helpers/string.helper')

let esformatter = require('esformatter');
esformatter.register(require('esformatter-jsx'));

let importList = {}
let LAYOUT_JSON = [];
let COMPONENTS_JSON = {};
let TEMPLATE_FOLDER;
let ROOT;

/**
 * 
 * @param {*} root : root location of source folder 'src'
 * @param {*} layoutDetails : layout details given in appMap.json
 * @param {*} config_folder : locatin of all the config files 
 * @param {*} template_folder : location of all the template files
 */
function createLayout(root, layoutDetails, config_folder, template_folder) {
    TEMPLATE_FOLDER = template_folder
    ROOT = root
    importList = {}
    const dir = `${root}src/layouts`
    const fileName = `${layoutDetails.name}.js`

    //reading and parsing configuration json
    LAYOUT_JSON = JSON.parse(fs.readFileSync(`./${config_folder}/${layoutDetails.name}_layout.json`, 'UTF8'))
    COMPONENTS_JSON = JSON.parse(fs.readFileSync(`./${config_folder}/${layoutDetails.name}_components.json`, 'UTF8'))

    //copy default components
    let componentDir = `${root}/src/components`

    writeFile(componentDir, `row.js`, fs.readFileSync(`./${template_folder}/templates/components/row.tpl.js`))
    writeFile(componentDir, `col.js`, fs.readFileSync(`./${template_folder}/templates/components/col.tpl.js`))
    importList['row'] = `import { Row } from './../components/row.js';`
    importList['col'] = `import { Col } from './../components/col.js';`

    //generating code for body
    let bodyCode = generateBodyCode(LAYOUT_JSON, '', '')

    let srcCode = generateCompleteCode(bodyCode, layoutDetails);

    //writing file
    writeFile(dir, fileName, esformatter.format(srcCode))
}

/**
 * generateBodyCode is recursive function, recursively it writes the code
 * @param {*} layout : json configuration of layout in json
 * @param {*} indents : no. of indents to be given in the current line of code
 * @param {*} srcCode : code written till yet
 */
function generateBodyCode(layout, indents, srcCode) {
    layout.forEach(item => {
        if (item.col) {
            srcCode += `${indents}<Col width="${item.col}">\n`
            if (item.row)
                srcCode = generateBodyCode(item.row, indents + '\t\t', srcCode + `${indents}\t<Row>\n`) + `${indents}\t</Row>\n`
            else
                srcCode += (item.component) ? `${indents}\t${resolveComponent(item.component)}\n` : ''
            srcCode += `${indents}</Col>\n`
        } else
            srcCode = generateBodyCode(item.row, indents + '\t\t', srcCode + `${indents}\t<Row>\n`) + `${indents}\t</Row>\n`
    })
    return srcCode;
}

/**
 * 
 * @param {*} bodyCode : code for component which is returned for rendering in react component
 * @param {*} layoutDetails : layout details given in appMap.json 
 */
function generateCompleteCode(bodyCode, layoutDetails) {
    let importCode = `import React, { Component } from 'react';`
    for (key in importList)
        importCode += `\n${importList[key]}`

    //console.log(importCode)

    let className = capitalize(layoutDetails.name)
    let classCode = `
    class ${className} extends Component {
        render() {
            return (
                <div>
                    ${bodyCode}
                </div>
            );
        }
    }
      
    export { ${className} }`

    return importCode + classCode
    //console.log(classCode)
}

/**
 * 
 * @param {*} componentName : name of the component to be imported (Capitalized name of component's type)
 * @param {*} fileName : component type (component file will be created in components folder with the name of components type)
 */
function importComponent(componentName, fileName) {
    let componentDir = `${ROOT}src/components`
    if (!importList[componentName]) {
        console.log(`importing component '${fileName}'...`)
        if (!fs.existsSync(`${componentDir}/${fileName}.js`))
            writeFile(componentDir, `${fileName}.js`, fs.readFileSync(`./${TEMPLATE_FOLDER}/templates/components/${fileName}.tpl.js`))
        importList[componentName] = `import { ${componentName} } from './../components/${fileName}.js' \n`
    }
}


/**
 * 
 * @param {*} id : Id of component to be added 
 */
function resolveComponent(id) {
    let componentName = capitalize(COMPONENTS_JSON[id].type)
    importComponent(componentName, COMPONENTS_JSON[id].type)
    let component = `<${componentName} id="${id}" spec={${objectify(JSON.stringify(COMPONENTS_JSON[id]))}}/>`
    return component
}


module.exports = createLayout