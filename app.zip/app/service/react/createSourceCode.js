const path = require('path')
const fs = require('fs')
const rimraf = require('rimraf')

const esformatter = require('esformatter');
esformatter.register(require('esformatter-jsx'));

const chalk = require('chalk')

const { writeFile, } = require('./../../helpers/file.helper')
const { capitalize, objectify } = require('./../../helpers/string.helper')

var createLayout = require('./createLayout')

module.exports = (function () {
    var generateAppSource = (args, callback) => {

        //source code for App.js
        var srcCode = ``;

        //import code for App.js
        let importCode = `import React, { Component } from 'react';\n`

        //reading appMap from config folder
        const appMap = JSON.parse(fs.readFileSync(`./${args.config_folder}/appMap.json`, 'UTF8'))

        //mainfile (entry file) for application
        let mainFile = '';

        //creating layouts
        appMap.forEach(layout => {
            console.log(`creating layout '${layout.name}'`)
            if (layout.type === 'main')
                mainFile = capitalize(layout.name)
            importCode += `import { ${capitalize(layout.name)} } from './layouts/${layout.name}';`
            createLayout(args.root, layout, args.config_folder, args.template_folder);
        });

        //temporary code
        let classCode = `
        class App extends Component {
            render() {
                return (
                    <${mainFile} />
                );
            }
        }
          
        export default App ;`

        writeFile(`${args.root}/src`, 'App.js', esformatter.format(importCode + classCode))

        console.log(chalk.bold.cyan(`app created :)`))
        callback()
    }


    return function (args, callback) {

        console.log(`creating source folder...`)
        let src = path.normalize(`${args.root}/src`)

        rimraf(src, function () {
            console.log(`writing index file...`)
            writeFile(src, 'index.js', fs.readFileSync(`${args.template_folder}/templates/index.tpl.js`))
            generateAppSource(args, callback)
        });

    }
})()