module.exports = {
    react: {
        name: "reactjs-module",
        templates: "http://localhost:8080/templates.zip",
    },
    angular5: {
        name: "angularjs-module",
        templates: "http://localhost:8080/angular_templates.zip",
    }
}